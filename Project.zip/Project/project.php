<?php
    $username = $_POST['uname'];
    $password = $_POST['psw'];
    if($username == "admin" and $password == "password") 
    {
        header("Location: welcome.php");
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>College Management System</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
    <form action="welcome.php" method="post">
        <b>Enter Username</b>   
        <input type="text" placeholder="Enter Username" name="uname" required>

        <b>Enter Password</b>
        <input type="password" placeholder="Enter Password" name="psw" required>

        <button type="submit">Login</button>
    </form>
</body>
</html>
