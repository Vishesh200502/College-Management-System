<!DOCTYPE html>
<html>
<head>
    <title>Student|College Management System<</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
        <br><br>
        <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 10px 10px;background-color: #FF4322"><a href="personal.php">PERSONAL DETAILS</a></button>
        <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 10px 10px;background-color: #3DEA8E"><a href="academic.php">ACADEMIC DETAILS</a></button>
        <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 10px 10px;background-color: #EEEE17"><a href="fee.php">FEES</a></button>
        <br>
        <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 400px 20px;background-color: #E351F5"><a href="welcome.php">BACK</a></button>
</body>
</html>