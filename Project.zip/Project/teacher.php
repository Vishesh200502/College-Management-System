<!DOCTYPE html>
<html>
<head>
    <title>Teacher|College Management System<</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
    <h2 style="background-color:yellow;font-family:verdana;text-align:center;font-size:200%";>FACULTY LIST</h2>
    <table border = "1" width=100%>
        <tr><th> TEACHER ID
            <th> NAME
            <th> EMAIL
            <th> PHONE NUMBER
            <th> COURSE CODE
            <th> BATCH
        </tr>  
        <?php
            $conn = mysqli_connect("localhost","root","","project");
            $query = "SELECT DISTINCT ti.teacherid,ti.name,ti.email,ti.phoneno,ti.coursecode,sc.batch FROM teacherinfo ti, studentcourses sc";
            $result = mysqli_query($conn,$query);
            if($result)
            {
                while($record = mysqli_fetch_assoc($result))
                {
                    echo "<tr><td>".$tid=$record['teacherid'];
                    echo "<td>".$name=$record['name'];
                    echo "<td>".$email=$record['email'];
                    echo "<td>".$phonenum=$record['phoneno'];
                    echo "<td>".$cc=$record['coursecode'];
                    echo "<td>".$batch=$record['batch'];
                }
            }
        ?>
    </table>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 400px 20px;background-color: #E351F5"><a href="welcome.php">BACK</a></button>
</body>
</html>