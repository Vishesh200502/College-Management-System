<!DOCTYPE html>
<html>
<head> 
    <title>New Entry|College Management System<</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
    <h2 style="background-color:yellow;font-family:verdana;text-align:center;font-size:200%";>NEW ENTRY</h2>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 50px 630px;background-color: #4CAF50"><a href="new_student.php">STUDENT</a></button>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 100px 630px;background-color: #FF334F"><a href="new_teacher.php">TEACHER</a></button>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 40px 20px;background-color: #E351F5"><a href="welcome.php">BACK</a></button>
</body>
</html>