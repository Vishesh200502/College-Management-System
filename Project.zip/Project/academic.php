<!DOCTYPE html>
<html>
<head>
    <title>Academic|College Management System</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
    <form method = "post">
        <b>Enter Your Name</b>   
        <input type="text" placeholder="Name" name="name" required>
        <br>
        <b>Enter Your Enrolment Number</b>
        <input type="number" placeholder="Enrolment Number" name="enrol" required>
        <br>
        <button type="submit">Login</button>
    </form>
    <table border = "1" width=100%>
        <tr><th> ROLL NUMBER
            <th> FIRST NAME
            <th> LAST NAME
            <th> COURSE CODE
            <th> BATCH
            <th> FACULTY
            <th> MARKS
            <th> ATTENDANCE
        </tr>   
        <?php
            $enroll = $_POST['enrol'];
            $conn = mysqli_connect("localhost","root","","project");
            $query = "SELECT si.roll_no,si.first_name,si.last_name,sc.coursecode,sc.batch,ti.name,sa.marks,sa.attendance FROM studentinfo si,teacherinfo ti,studentcourses sc,studentacad sa WHERE (si.roll_no = sc.rollno) and (si.roll_no = sa.rollno) and (sc.coursecode = ti.coursecode) and si.roll_no = $enroll";
            $result = mysqli_query($conn,$query);
            if($result)
            {
                while($record = mysqli_fetch_assoc($result))
                {
                    echo "<tr><td>".$roll=$record['roll_no'];
                    echo "<td>".$fname=$record['first_name'];
                    echo "<td>".$lname=$record['last_name'];
                    echo "<td>".$cc=$record['coursecode'];
                    echo "<td>".$batch=$record['batch'];
                    echo "<td>".$fac=$record['name'];
                    echo "<td>".$marks=$record['marks'];
                    echo "<td>".$attend=$record['attendance'];
                }
            }
        ?>
    </table>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 400px 20px;background-color: #E351F5"><a href="student.php">BACK</a></button>
</body>
</html>