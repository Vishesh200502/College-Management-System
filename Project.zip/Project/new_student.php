<!DOCTYPE html>
<html>
<head>
    <title>New Student|College Management System</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
    <form method = "post">
        <b>Enter Roll Number</b>
        <input type="number" placeholder="Roll Number" name="Roll" required>  
        <br>  
        <b>Enter First Name</b>   
        <input type="text" placeholder="First Name" name="fname" required>
        <br>
        <b>Enter Last Name</b>   
        <input type="text" placeholder="Last Name" name="lname" required>
        <br>
        <b>Enter Father's Name</b>   
        <input type="text" placeholder="Father's Name" name="fatname" required>
        <br>
        <b>Enter Email</b>   
        <input type="text" placeholder="Email" name="email" required>
        <br>
        <b>Enter Mobile Number</b>   
        <input type="number" placeholder="Mobile Number" name="mobile" required>
        <br>
        <b>Enter Course Code</b>   
        <input type="text" placeholder="Course Code" name="course" required>
        <br>
        <b>Enter Batch</b>   
        <input type="text" placeholder="Batch" name="batch" required>
        <br>
        <b>Enter Faculty</b>   
        <input type="text" placeholder="Faculty" name="faculty" required>
        <br>
        <b>Enter Marks</b>   
        <input type="number" placeholder="Marks" name="marks" required>
        <br>
        <b>Enter Attendance</b>   
        <input type="number" placeholder="Attendance" name="attendance" required>
        <br>
        <b>Enter Amount</b>   
        <input type="number" placeholder="Amount" name="amount" required>
        <br>
        <b>Enter Due Date</b>   
        <input type="date" placeholder="Due Date" name="due" required>
        <br>
        <b>Enter Status</b>   
        <input type="text" placeholder="Status" name="status" required>
        <br>
        <button type="submit">Submit</button>
    </form>
        <?php
            $conn = mysqli_connect("localhost","root","","project");
            $query1 = "INSERT INTO studentinfo (roll_no,first_name,last_name,father_name,email,mobile_no) VALUES ('$_POST[Roll]','$_POST[fname]','$_POST[lname]','$_POST[fatname]','$_POST[email]','$_POST[mobile]')";
            $result1 = mysqli_query($conn,$query1);
            $query2 = "INSERT INTO studentcourses (coursecode,batch) VALUES ('$_POST[course]','$_POST[batch]')";
            $result2 = mysqli_query($conn,$query2);
            $query3 = "INSERT INTO teacherinfo (name) VALUES ('$_POST[faculty]')";
            $result3 = mysqli_query($conn,$query3);
            $query4 = "INSERT INTO studentacad (marks,attendance) VALUES ('$_POST[marks]','$_POST[attendance]')";
            $result4 = mysqli_query($conn,$query4);
            $query5 = "INSERT INTO studentfeerecord (amount,duedate,status) VALUES ('$_POST[amount]','$_POST[due]','$_POST[status]')";
            $result5 = mysqli_query($conn,$query5);
        ?>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 200px 20px;background-color: #E351F5"><a href="new.php">BACK</a></button>
</body>
</html>