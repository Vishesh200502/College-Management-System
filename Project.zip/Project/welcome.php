<!DOCTYPE html>
<html>
<head> 
    <title>Welcome|College Management System<</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
    <h2 style="background-color:yellow;font-family:verdana;text-align:center;font-size:200%";>WELCOME</h2>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 30px 630px;background-color: #4CAF50"><a href="student.php">STUDENT</a></button>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 60px 630px;background-color: #FF334F"><a href="teacher.php">TEACHER</a></button>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 90px 630px;background-color: #33A2FF"><a href="new.php">NEW ENTRY</a></button>
</body>
</html>