<!DOCTYPE html>
<html>
<head>
    <title>New Teacher|College Management System</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
    <form method = "post">
        <b>Enter Teacher ID</b>
        <input type="number" placeholder="Teacher ID" name="teacherid" required>  
        <br>  
        <b>Enter Name</b>   
        <input type="text" placeholder="Name" name="name" required>
        <br>
        <b>Enter Email</b>   
        <input type="text" placeholder="Email" name="email" required>
        <br>
        <b>Enter Mobile Number</b>   
        <input type="number" placeholder="Mobile Number" name="mobile" required>
        <br>
        <b>Enter Course Code</b>   
        <input type="text" placeholder="Course Code" name="course" required>
        <br>
        <button type="submit">Submit</button>
    </form>
        <?php
            $conn = mysqli_connect("localhost","root","","project");
            $query = "INSERT INTO teacherinfo (teacherid,name,email,phoneno,coursecode) VALUES ('$_POST[teacherid]','$_POST[name]','$_POST[email]','$_POST[mobile]','$_POST[course]')";
            $result = mysqli_query($conn,$query);
            if($result)
            {
                echo "Registration Successful.";
            }
        ?>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 200px 20px;background-color: #E351F5"><a href="new.php">BACK</a></button>
</body>
</html>