<!DOCTYPE html>
<html>
<head>
    <title>Fees|College Management System</title>
</head>
<body>
    <h1 style="background-color:powderblue;font-family:verdana;text-align:center;font-size:300%";>COLLEGE MANAGEMENT SYSTEM</h1>
    <form method = "post">
        <b>Enter Your Name</b>   
        <input type="text" placeholder="Name" name="name" required>
        <br>
        <b>Enter Your Enrolment Number</b>
        <input type="number" placeholder="Enrolment Number" name="enrol" required>
        <br>
        <button type="submit">Login</button>
    </form>
    <table border = "1" width=100%>
        <tr><th> ROLL NUMBER
            <th> FIRST NAME
            <th> LAST NAME
            <th> EMAIL
            <th> AMOUNT
            <th> DUE DATE
            <th> STATUS
        </tr>   
        <?php
            $enroll = $_POST['enrol'];
            $conn = mysqli_connect("localhost","root","","project");
            $query = "SELECT si.roll_no,si.first_name,si.last_name,si.email,sf.amount,sf.duedate,sf.status FROM studentinfo si,studentfeerecord sf WHERE (si.roll_no = sf.rollno) and si.roll_no = $enroll";
            $result = mysqli_query($conn,$query);
            if($result)
            {
                while($record = mysqli_fetch_assoc($result))
                {
                    echo "<tr><td>".$roll=$record['roll_no'];
                    echo "<td>".$fname=$record['first_name'];
                    echo "<td>".$lname=$record['last_name'];
                    echo "<td>".$email=$record['email'];
                    echo "<td>".$amount=$record['amount'];
                    echo "<td>".$dd=$record['duedate'];
                    echo "<td>".$status=$record['status'];
                }
            }
        ?>
    </table>
    <button type="submit" style="color: white;padding: 15px 32px;text-align: center;font-size: 20px;margin: 400px 20px;background-color: #E351F5"><a href="student.php">BACK</a></button>
</body>
</html>